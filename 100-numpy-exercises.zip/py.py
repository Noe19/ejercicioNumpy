""""
W = np.zeros(10)
print (W)

W = np.zeros(10)
W[4]= 1
print (W)

W = np.arange (10,50)
print (W)

W = np.arange(50)
W = W[::-1]

w = np.arange(9).reshape(3,3)
print (w)

nz = np.nonzero([1,2,0,0,4,0])
print(nz)
"""